/**
 * Created by miffy on 2017/7/27
 */
import React from 'react'

const noMatch = (props) => (
  <h1>404</h1>
)

export default noMatch;

