import React, {Component} from 'react'

export default class KnowledgeGraph extends Component {
  render() {
    return (
      <div>知识图谱</div>
    )
  }
}
