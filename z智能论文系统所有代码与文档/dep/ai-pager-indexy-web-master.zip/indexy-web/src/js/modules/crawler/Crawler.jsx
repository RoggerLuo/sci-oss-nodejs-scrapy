import React, {Component} from 'react'

export default class Crawler extends Component {
  render() {
    return (
      <div>Crawler</div>
    )
  }
}
