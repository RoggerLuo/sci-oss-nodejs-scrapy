const constant = {
  tableScrollWith: 850
}

export default constant