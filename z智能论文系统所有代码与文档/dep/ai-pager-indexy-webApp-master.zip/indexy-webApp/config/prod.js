const development = {

  staticUrl: "",

  // 描述前端有多少个entry
  entries: {
    'index': `./src/js/app/index.jsx`,
  }

}

module.exports = development
