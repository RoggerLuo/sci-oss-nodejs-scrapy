# indexy-webApp
WebApp（Hybrid App ）

- 下载环境

```
$ npm i -g restackx-cli@1.0.2
```

- 克隆项目

```
$ git clone https://gitee.com/ai-pager/indexy-webApp
```

- 下载依赖

```
$ npm install
```
 
- 启动项目

```
$ npm start
```

- 项目打包

```
$ npm run build-prod
```

- 生产环境下运行

```
$ npm run prod
```