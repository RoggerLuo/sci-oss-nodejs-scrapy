# indexy-crawler-api

基于任务管理的爬虫引擎，本项目以`“学术论文”`领域作为实践案例。

## 功能模块

- 任务管理

- 任务结果

- 文章管理


## 系统架构

![输入图片说明](https://gitee.com/uploads/images/2017/1027/153305_681cab09_23200.png "屏幕截图.png")

## 业务流程

![输入图片说明](https://gitee.com/uploads/images/2017/1027/154048_70b8dcf0_23200.png "屏幕截图.png")

## 技术选型

## 数据结构

## 系统截图

## TODO

## 参考
