'use strict';


// exports.validate = {
//   enable: false,
//   package: 'egg-validate',
// };

// exports.logrotator = {
// 	enable: true,
// 	package: 'egg-logrotator',
// 	env: [ 'prod' ]
// };
