'use strict';

// https://github.com/uphold/koa-requestid

module.exports = require('koa-requestid');
