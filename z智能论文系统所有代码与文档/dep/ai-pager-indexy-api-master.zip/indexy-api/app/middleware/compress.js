'use strict';

// https://github.com/koajs/compress/blob/master/index.js

module.exports = require('koa-compress');
